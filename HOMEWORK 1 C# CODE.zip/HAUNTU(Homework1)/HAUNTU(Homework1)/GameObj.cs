﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace HAUNTU_Homework1_
{
    internal class GameObj
    {
        public Vector2 position;

        public GameObj(Vector2 position)
        {
            this.position = position;
        }
    }
}
